import pickle
import os
from flask import Flask, render_template, request
import pandas as pd
import numpy as np

app = Flask(__name__, template_folder='templates', static_folder='static')

# PATHS 
MODEL_PATH = 'model.pkl'
PREPROCESSOR_PATH = 'preprocessors.pkl'
PROCESSED_DATA_CSV = 'processed_data.csv'

#  LOAD MODEl
if not os.path.exists(MODEL_PATH):
    raise FileNotFoundError(f"Model not found at {MODEL_PATH}")

with open(MODEL_PATH, 'rb') as f:
    model = pickle.load(f)


#  CORRECT TRAINING FEATURE ORDER 
# (G1 IS REMOVED because G1 was your target while training)
# Your model was trained on ALL COLUMNS EXCEPT G1
feature_order = [
    'school','sex','age','address','famsize','Pstatus','Medu','Fedu','Mjob','Fjob',
    'reason','guardian','traveltime','studytime','failures','schoolsup','famsup',
    'paid','activities','nursery','higher','internet','romantic','famrel','freetime',
    'goout','Dalc','Walc','health','absences','G2','G3'
]


#  LOAD PREPROCESSORS 
preprocessors = {}
if os.path.exists(PREPROCESSOR_PATH):
    try:
        with open(PREPROCESSOR_PATH, 'rb') as f:
            preprocessors = pickle.load(f)
        if 'feature_order' in preprocessors:
            feature_order = preprocessors['feature_order']
    except:
        print("Could not load preprocessors.pkl")


# LOAD CSV 
processed_data = None
if os.path.exists(PROCESSED_DATA_CSV):
    try:
        processed_data = pd.read_csv(PROCESSED_DATA_CSV)
    except:
        print("processed_data.csv could not be loaded")


#  DROPDOWN HELPER 
def get_sample_data():
    return {
        'school': ['GP', 'MS'],
        'sex': ['F', 'M'],
        'address': ['U', 'R'],
        'famsize': ['GT3', 'LE3'],
        'Pstatus': ['T', 'A'],
        'schoolsup': ['yes', 'no'],
        'famsup': ['yes', 'no'],
        'paid': ['yes', 'no'],
        'activities': ['yes', 'no'],
        'nursery': ['yes', 'no'],
        'higher': ['yes', 'no'],
        'internet': ['yes', 'no'],
        'romantic': ['yes', 'no'],
    }


#  DEFAULT VALUES 
default_values = {
    'age': 17,
    'famsize': 'GT3', 'Pstatus': 'T',
    'Medu': 2, 'Fedu': 2,
    'Mjob': 'other', 'Fjob': 'other',
    'reason': 'home', 'guardian': 'mother',
    'traveltime': 1, 'studytime': 2,
    'failures': 0, 'schoolsup': 'no', 'famsup': 'no',
    'paid': 'no', 'activities': 'no',
    'nursery': 'no', 'higher': 'yes',
    'internet': 'no', 'romantic': 'no',
    'famrel': 3, 'freetime': 3, 'goout': 3,
    'Dalc': 1, 'Walc': 1, 'health': 3, 'absences': 0,
    'G2': 10, 'G3': 10
}


# ROUTES
@app.route('/')
def index():
    return render_template('index.html', sample_data=get_sample_data())


@app.route('/predict', methods=['POST'])
def predict():
    form = request.form.to_dict()
    input_data = {}

    # Convert inputs
    for k, v in form.items():
        if v == "":
            input_data[k] = np.nan
        else:
            try:
                input_data[k] = int(v)
            except:
                try:
                    input_data[k] = float(v)
                except:
                    input_data[k] = v

    # Add defaults for missing values
    for k, val in default_values.items():
        if k not in input_data:
            input_data[k] = val

    # Create dataframe
    df = pd.DataFrame([input_data])

    # Keep only training features
    df = df[[c for c in df.columns if c in feature_order]]

    # Add missing columns
    for col in feature_order:
        if col not in df.columns:
            df[col] = default_values.get(col, 0)

    # Correct feature order
    df = df[feature_order]

    #  ENCODING 
    if preprocessors and 'label_encoders' in preprocessors:
        for col, le in preprocessors['label_encoders'].items():
            if col in df.columns:
                try:
                    df[col] = df[col].astype(str)
                    df[col] = le.transform(df[col])
                except:
                    df[col] = -1
    else:
        # Basic fallback encoders
        yes_no = {'yes': 1, 'no': 0}
        for col in df.select_dtypes(include=['object']).columns:
            df[col] = df[col].astype(str).str.lower()
            df[col] = df[col].map(yes_no).fillna(df[col])

            df[col] = df[col].replace({'gp': 0, 'ms': 1})
            df[col] = df[col].replace({'f': 0, 'm': 1})
            df[col] = df[col].replace({'u': 0, 'r': 1})
            df[col] = df[col].replace({'gt3': 0, 'le3': 1})
            df[col] = df[col].replace({'t': 0, 'a': 1})

            df[col] = df[col].replace({
                'teacher': 0, 'health': 1, 'services': 2, 'at_home': 3, 'other': 4
            })

            df[col] = df[col].replace({
                'home': 0, 'reputation': 1, 'course': 2, 'other': 3
            })

            df[col] = df[col].replace({
                'mother': 0, 'father': 1, 'other': 2
            })

            df[col] = pd.to_numeric(df[col], errors='coerce').fillna(-1)

    #  SCALING 
    if preprocessors and 'scaler' in preprocessors:
        try:
            df = pd.DataFrame(
                preprocessors['scaler'].transform(df),
                columns=feature_order
            )
        except:
            pass

    #  PREDICT 
    try:
        prediction = model.predict(df)[0]
    except Exception as e:
        return render_template('index.html',
                               sample_data=get_sample_data(),
                               error=f"Prediction failed: {e}")

    return render_template('index.html',
                           sample_data=get_sample_data(),
                           predicted=prediction)


if __name__ == '__main__':
    app.run(debug=True)
